// script.js
document.addEventListener("DOMContentLoaded", function () {
    // Add your JavaScript code here
    // For example, you can add an event listener or create interactive elements.
    
    // Example: Change the text of a button when clicked
    const button = document.getElementById("myButton");
    button.addEventListener("click", function () {
        button.textContent = "Clicked!";
    });
});
